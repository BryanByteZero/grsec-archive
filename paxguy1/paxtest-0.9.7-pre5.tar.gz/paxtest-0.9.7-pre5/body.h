void itworked( void );
void itfailed( void );
int do_mprotect( const void *addr, size_t len, int prot );
typedef void (*fptr)(void);
